exec sp_addlinkedserver 'ITSV ', ' ', 'SQLOLEDB ', '121.42.158.4' 
exec sp_addlinkedsrvlogin 'ITSV ', 'false ',null, 'sa', '1qaz2wsx3edc123'

--��ѯʾ�� 
select top 10 * from ITSV.YDBS_MFQJ_DWZ.dbo.Data_SUrl_1
select top 10 * from ITSV.YDBS_MFQJ_User.dbo.UserPassport

--����ʾ�� 
select top 100 * into  QuestionBase   from ITSV.YDBS_MFQJ_Question.dbo.QuestionBase   
select top 100 * into  QuestionAnswerInfo   from ITSV.YDBS_MFQJ_Question.dbo.QuestionAnswerInfo   
select top 100 * into  Question_ZSDMap    from ITSV.YDBS_MFQJ_Question.dbo.Question_ZSDMap		  
select top 100 * into  QuestionItem    from ITSV.YDBS_MFQJ_Question.dbo.QuestionItem	  
select top 100 * into  QuestionFrom    from ITSV.YDBS_MFQJ_Question.dbo.QuestionFrom   


select top 100 * into  QuestionClass     from ITSV.YDBS_MFQJ_Question.dbo.QuestionClass    
select top 100 * into  Question_KDMap    from ITSV.YDBS_MFQJ_Question.dbo.Question_KDMap   
select top 100 * into  TeacherClassStdents    from ITSV.YDBS_MFQJ_Question.dbo.TeacherClassStdents   
select top 100 * into  TeacherPointConsumeLog    from ITSV.YDBS_MFQJ_Question.dbo.TeacherPointConsumeLog		   
select top 100 * into  TeacherMessage    from ITSV.YDBS_MFQJ_Question.dbo.TeacherMessage   


select top 100 * into  TeacherMessage     from ITSV.YDBS_MFQJ_Question.dbo.TeacherMessage		   
select top 100 * into  CommentsClass	   from ITSV.YDBS_MFQJ_Question.dbo.CommentsClass	  
select top 100 * into  CommentsList     from ITSV.YDBS_MFQJ_Teacher.dbo.CommentsList    
select top 100 * into  TeacherOperLog     from ITSV.YDBS_MFQJ_Question.dbo.TeacherOperLog				   
select top 100 * into  TeacherMessage    from ITSV.YDBS_MFQJ_Question.dbo.TeacherMessage   

select top 100 *  from  ITSV.YDBS_MFQJ_User.dbo.UserPassport 



--�Ժ���ʹ��ʱɾ�����ӷ����� 
--exec sp_dropserver 'ITSV ', 'droplogins '